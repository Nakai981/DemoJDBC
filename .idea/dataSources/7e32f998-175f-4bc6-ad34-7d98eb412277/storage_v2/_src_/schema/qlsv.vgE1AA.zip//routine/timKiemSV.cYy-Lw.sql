create
    definer = root@localhost procedure timKiemSV(IN diachi varchar(30))
begin
	select sinhvien.masv, sinhvien.tensv, sinhvien.ngaysinh, sinhvien.gioitinh, sinhvien.diachi
    from sinhvien
    where sinhvien.diachi = diachi;
end;

